package org.robolectric.shadows;

import android.graphics.BitmapShader;
import org.robolectric.annotation.Implements;

@Implements(BitmapShader.class)
public class ShadowBitmapShader {
}

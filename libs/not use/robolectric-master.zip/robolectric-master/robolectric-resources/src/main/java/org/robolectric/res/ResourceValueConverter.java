package org.robolectric.res;

public interface ResourceValueConverter {
  Object convertRawValue(String rawValue);
}

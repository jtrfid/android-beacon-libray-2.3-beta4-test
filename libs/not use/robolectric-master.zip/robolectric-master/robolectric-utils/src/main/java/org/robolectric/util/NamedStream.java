package org.robolectric.util;

public interface NamedStream {
}

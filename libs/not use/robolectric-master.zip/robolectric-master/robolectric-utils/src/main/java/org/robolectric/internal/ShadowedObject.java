package org.robolectric.internal;

public interface ShadowedObject {
  Object $$robo$getData();
}

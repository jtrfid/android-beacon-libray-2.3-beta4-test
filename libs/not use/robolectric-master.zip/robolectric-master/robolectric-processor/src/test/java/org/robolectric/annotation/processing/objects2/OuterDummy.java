package org.robolectric.annotation.processing.objects2;

public class OuterDummy {

  public class InnerDummy {
    
  }
}

package org.robolectric.util;

public class TimeUtils {
  public static final long NANOS_PER_MS = 1000000;
}

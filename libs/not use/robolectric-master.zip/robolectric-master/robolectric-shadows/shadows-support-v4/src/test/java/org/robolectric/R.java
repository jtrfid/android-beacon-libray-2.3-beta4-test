package org.robolectric;

public final class R {
  public static final class id {
    public static final int title = 0x10001;
    public static final int fragment = 0x10022;
    public static final int tacos = 0x10027;
    public static final int burritos = 0x10028;
  }

  public static final class drawable {
    public static final int robolectric = 0x10511;
  }

  public static final class layout {
    public static final int dialog_fragment = 0x1060f;
    public static final int fragment = 0x10607;
    public static final int fragment_contents = 0x10609;
    public static final int activity_fragment = 0x10620;
  }
}

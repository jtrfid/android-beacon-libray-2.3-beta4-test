package org.robolectric.internal;

public interface ShadowProvider {

  void reset();
}

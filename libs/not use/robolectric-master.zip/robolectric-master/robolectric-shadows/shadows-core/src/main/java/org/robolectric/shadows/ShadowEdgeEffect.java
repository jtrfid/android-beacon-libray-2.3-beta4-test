package org.robolectric.shadows;

import org.robolectric.annotation.Implements;

@Implements(className = "android.widget.EdgeEffect")
public class ShadowEdgeEffect {
}

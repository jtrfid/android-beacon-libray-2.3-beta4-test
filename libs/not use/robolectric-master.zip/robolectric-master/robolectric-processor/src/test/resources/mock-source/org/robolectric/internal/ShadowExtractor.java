package org.robolectric.internal;

public class ShadowExtractor {

  public static Object extract(Object source) {
    return null;
  }
}

package org.robolectric.shadows;

import android.media.MediaScannerConnection;
import org.robolectric.annotation.Implements;

@Implements(MediaScannerConnection.class)
public class ShadowMediaScannerConnection {
}

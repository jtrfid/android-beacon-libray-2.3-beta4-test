package org.robolectric.shadows;

public interface Provider<T> {
  T get();
}

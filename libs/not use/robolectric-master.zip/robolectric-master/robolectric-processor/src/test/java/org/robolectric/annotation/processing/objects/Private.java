package org.robolectric.annotation.processing.objects;

class Private {
}

package org.robolectric.res;

public interface Style {
  Attribute getAttrValue(ResName resName);
}

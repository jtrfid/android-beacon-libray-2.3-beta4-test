package org.robolectric.annotation;

import org.robolectric.annotation.UnrecognizedAnnotation;

@UnrecognizedAnnotation
public class TestWithUnrecognizedAnnotation {
}

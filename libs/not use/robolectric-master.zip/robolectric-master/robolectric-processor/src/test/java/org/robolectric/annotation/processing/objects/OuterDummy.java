package org.robolectric.annotation.processing.objects;

public class OuterDummy {
  public class InnerDummy {
  }
}

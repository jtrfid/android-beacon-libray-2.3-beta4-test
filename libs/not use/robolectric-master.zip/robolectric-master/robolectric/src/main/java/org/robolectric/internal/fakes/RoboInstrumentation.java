package org.robolectric.internal.fakes;

import android.app.Instrumentation;

public class RoboInstrumentation extends Instrumentation {
}

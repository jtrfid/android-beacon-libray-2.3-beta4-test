package org.robolectric.annotation.processing.shadows;

import org.robolectric.annotation.RealObject;

public class ShadowRealObjectWithoutImplements {

  @RealObject Object someField;
}

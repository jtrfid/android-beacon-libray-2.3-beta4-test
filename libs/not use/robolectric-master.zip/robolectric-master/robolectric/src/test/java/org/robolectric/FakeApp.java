package org.robolectric;

import android.app.Application;
import org.robolectric.annotation.internal.Instrument;

@Instrument
public class FakeApp extends Application {
}

package org.robolectric.annotation.processing.objects;

public class Dummy {
}

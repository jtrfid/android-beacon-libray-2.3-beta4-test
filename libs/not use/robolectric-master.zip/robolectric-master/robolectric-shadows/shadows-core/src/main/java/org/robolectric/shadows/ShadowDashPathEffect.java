package org.robolectric.shadows;

import android.graphics.DashPathEffect;
import org.robolectric.annotation.Implements;

@Implements(DashPathEffect.class)
public class ShadowDashPathEffect {
}

package org.robolectric.internal.bytecode;

public class DirectObjectMarker {
  public static final DirectObjectMarker INSTANCE = new DirectObjectMarker() {
  };

  private DirectObjectMarker() {
  }
}

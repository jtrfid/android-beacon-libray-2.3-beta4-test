package org.robolectric.annotation.processing.objects;

public class ParameterizedDummy<T, N extends Number> {

}

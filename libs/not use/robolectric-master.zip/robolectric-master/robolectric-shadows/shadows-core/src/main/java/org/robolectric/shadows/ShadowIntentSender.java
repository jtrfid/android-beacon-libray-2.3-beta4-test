package org.robolectric.shadows;

import android.content.IntentSender;
import org.robolectric.annotation.Implements;

@Implements(IntentSender.class)
public class ShadowIntentSender {
}

package org.robolectric.annotation.processing.objects;

public class UniqueDummy {

  public class InnerDummy {
  }

  public class UniqueInnerDummy {
  }
}
